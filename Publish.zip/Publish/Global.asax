﻿<%@ Application Codebehind="Global.asax.cs" Inherits="EBCaseStudy.MvcApplication" Language="C#" %>
