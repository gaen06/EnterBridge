﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        ProductApiService _productService = new ProductApiService();
        public async Task<ActionResult> Index(int page = 1)
        {
            var result = await _productService.GetProducts(page, 5);

            ViewBag.Page = result.PageNumber;
            ViewBag.TotalPages = result.TotalPages;
            ViewBag.HasNext = result.HasNextPage;
            ViewBag.HasPrev = result.HasPreviousPage;

            return View(result.Items);
        }

        public async Task<ActionResult> Prices(int productId = 1, int page = 1)
        {
            var startDate = new DateTime(2023, 01, 01); // DateTime.Now.AddMonths(-6); No new data

            var result = await _productService.GetPrices(productId, startDate, page);

            ViewBag.ProductName = result.Items.FirstOrDefault()?.Product?.Name;
            ViewBag.Page = result.PageNumber;
            ViewBag.TotalPages = result.TotalPages;

            return View(result.Items);
        }

        public async Task<ActionResult> PriceChart(int productId = 1, int page = 1)
        {
            var result = await _productService.GetPrices(
                productId,
                new DateTime(2023, 1, 1),
                page);

            var model = new PriceHistoryViewModel
            {
                ProductId = productId,
                ProductName = result.Items.FirstOrDefault()?.Product?.Name,
                Prices = result.Items.OrderBy(p => p.DateTime).ToList(),
                PageNumber = result.PageNumber,
                TotalPages = result.TotalPages
            };

            return View(model);
        }
    }
}