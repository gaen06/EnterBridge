﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using WebApplication2.DBModels;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class OrdersController : Controller
    {
        ProductApiService _productService = new ProductApiService();
        DBEntities db = new DBModels.DBEntities();


        public ActionResult Index(string submittedBy = "User")
        {
            IEnumerable<WebApplication2.DBModels.Orders> orders = db.Orders
                                                                      .Where(o => o.SubmittedBy == submittedBy)
                                                                      .ToList();

            return View(orders);
        }

        // GET: Orders
        public async Task<ActionResult> AddToOrder(int productId)
        {
            var product = await _productService.GetProduct(productId);

            var price = await _productService.GetLatestPrice(productId);

            var cart =
                Session["Cart"] as List<CartItem>
                ?? new List<CartItem>();

            var existing =
                cart.FirstOrDefault(x => x.ProductId == productId);

            if (existing != null)
            {
                existing.Quantity++;
            }
            else
            {
                cart.Add(new CartItem
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    UnitPrice = price.Amount,
                    Quantity = 1
                });
            }

            Session["Cart"] = cart;

            return RedirectToAction("Cart");
        }

        public ActionResult Cart()
        {
            var cart =
                Session["Cart"] as List<CartItem>
                ?? new List<CartItem>();

            return View(cart);
        }

        //[HttpPost]
        public ActionResult Checkout(string submittedBy = "")
        {
            var cart =
                Session["Cart"] as List<CartItem>;

            if (cart == null || !cart.Any())
                return RedirectToAction("Cart");

            var order = new Orders
            {
                SubmittedBy = submittedBy,
                OrderDate = DateTime.Now,
                Status = "Pending",
                Items = cart.Select(c => new OrderItems
                {
                    ProductId = c.ProductId,
                    ProductName = c.ProductName,
                    UnitPrice = c.UnitPrice,
                    Quantity = c.Quantity
                }).ToList()
            };

            db.Orders.Add(order);

            db.SaveChanges();

            Session["Cart"] = null;

            return RedirectToAction("Index");
        }
        public ActionResult Reorder(int id)
        {
            var order =
                db.Orders
                  .Include("Items")
                  .FirstOrDefault(o => o.OrderId == id);

            var cart = order.Items.Select(i =>
                new CartItem
                {
                    ProductId = i.ProductId,
                    ProductName = i.ProductName,
                    UnitPrice = i.UnitPrice,
                    Quantity = i.Quantity
                })
                .ToList();

            Session["Cart"] = cart;

            return RedirectToAction("Cart");
        }
    }
}