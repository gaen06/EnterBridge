﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class FavoriteProduct
    {
        public int Id { get; set; }

        public int ProductId { get; set; }

        public string ProductName { get; set; }
    }
}