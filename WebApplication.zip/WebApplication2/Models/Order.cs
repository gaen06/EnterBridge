﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class Order
    {
        public int Id { get; set; }

        public string SubmittedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string Status { get; set; } = "Pending";

        public ICollection<OrderItem> Items { get; set; }

        public override bool Equals(object obj)
        {
            var newOrder = (WebApplication2.DBModels.Orders)obj;

            newOrder.OrderDate = this.CreatedDate;
            newOrder.OrderId = this.Id;
            newOrder.Status = this.Status;
            newOrder.SubmittedBy = this.SubmittedBy;

            return base.Equals(obj);
        }
    }
}