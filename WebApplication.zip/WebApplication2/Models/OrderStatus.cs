﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public enum OrderStatus
    {
        Pending,
        Approved,
        Rejected
    }
}