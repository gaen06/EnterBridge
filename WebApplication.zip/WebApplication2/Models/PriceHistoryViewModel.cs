﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class PriceHistoryViewModel
    {
        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public List<PriceItemViewModel> Prices { get; set; }

        public int PageNumber { get; set; }

        public int TotalPages { get; set; }
    }
}