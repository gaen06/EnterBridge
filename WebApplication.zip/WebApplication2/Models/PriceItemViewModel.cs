﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class PriceItemViewModel
    {
        public int Id { get; set; }

        public decimal Amount { get; set; }

        public DateTime DateTime { get; set; }

        public decimal Quantity { get; set; }

        public string UnitOfMeasure { get; set; }

        public int ProductId { get; set; }

        public ProductMiniViewModel Product { get; set; }
    }
}