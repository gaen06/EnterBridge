﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class PriceViewModel
    {
        public DateTime Date { get; set; }
        public decimal Value { get; set; }
    }
}