﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using WebApplication2.Service;

namespace WebApplication2.Models
{
    public class ProductApiService
    {
        private readonly HttpClient _client;
        private static List<ProductViewModel> _allProducts;

        public ProductApiService()
        {
            _client = new HttpClient();
            _client.BaseAddress =
                new Uri("https://api.casestudy.enterbridge.com/");
        }

        public async Task<PagedProductResponse> GetProducts(int page = 1, int pageSize = 5)
        {
            var url = $"api/products?pageNumber={page}&pageSize={pageSize}";

            var response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                throw new Exception("Failed to load products from API");

            var json = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<PagedProductResponse>(json);
        }

        public async Task<PagedPriceResponse> GetPrices(int productId, DateTime startDate, int page = 1)
        {
            var url = $"api/prices?productId={productId}&startDate={startDate:yyyy-MM-dd}&pageNumber={page}&pageSize=10";

            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();

            return JsonConvert.DeserializeObject<PagedPriceResponse>(json);
        }

        public async Task<ProductViewModel> GetProduct(int productId)
        {
            var products = await GetAllProducts();

            return products.FirstOrDefault(p => p.Id == productId);
        }

        public async Task<List<ProductViewModel>> GetAllProducts()
        {
            if (_allProducts != null)
                return _allProducts;

            _allProducts = new List<ProductViewModel>();

            int page = 1;

            while (true)
            {
                var result = await GetProducts(page, 100);

                _allProducts.AddRange(result.Items);

                if (!result.HasNextPage)
                    break;

                page++;
            }

            return _allProducts;
        }

        public async Task<PriceItemViewModel> GetLatestPrice(int productId)
        {
            var url =
                $"api/prices?productId={productId}&pageNumber=1&pageSize=1";

            var response = await _client.GetAsync(url);

            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();

            var result =
                JsonConvert.DeserializeObject<PagedPriceResponse>(json);

            return result.Items.FirstOrDefault();
        }
    }
}